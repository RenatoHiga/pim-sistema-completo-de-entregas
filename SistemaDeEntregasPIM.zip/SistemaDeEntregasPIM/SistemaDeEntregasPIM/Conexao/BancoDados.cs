﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaDeEntregasPIM.Conexao {
    class BancoDados {
        public static string PegarLinhaDeConexao() {
            return "Server = LAPTOP-OOP2O013; Database = SistemaEntrega; Trusted_Connection = True;";
        }
    }
}
