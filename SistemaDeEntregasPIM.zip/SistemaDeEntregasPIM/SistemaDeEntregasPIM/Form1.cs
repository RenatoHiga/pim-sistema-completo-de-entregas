﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using SistemaDeEntregasPIM.Conexao;

namespace SistemaDeEntregasPIM {
    public partial class Form1 : Form {

        string SqlConnection;

        public Form1() {
            InitializeComponent();
            SqlConnection = BancoDados.PegarLinhaDeConexao();
        }

        private void button1_Click(object sender, EventArgs e) {



            try {
                // instantiate and open connection
                SqlConnection conn = new SqlConnection(SqlConnection);

                SqlCommand cmd = new SqlCommand("select * from Usuarios where login_usuario = '" + login.Text + "'", conn);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                Console.WriteLine("oi?");
                while (reader.Read()) {

                    if (reader["login_usuario"].ToString() == login.Text) {
                        Console.WriteLine("WHY");
                        string id = reader["id_usuario"].ToString();
                        //int idCliente = Convert.ToInt32(reader["id_usuario"]);
                        Console.WriteLine(id + "+" + "why");
                        break;
                    }
                    
                }
            }
            finally {
                // Fecha o datareader
                //if (reader != null) {
                //    reader.Close();
                ///

                // Fecha a conexão
                //if (conn != null) {
                  //  conn.Close();
                //}
            }

        }

        private void label5_Click(object sender, EventArgs e) {
            this.Visible = false;
            FormularioDeCadastro formCadastro = new FormularioDeCadastro();
            formCadastro.Show();
        }
    }
}
