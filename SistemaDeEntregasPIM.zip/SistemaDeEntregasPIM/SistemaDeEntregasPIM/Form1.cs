﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using SistemaDeEntregasPIM.Conexao;
using SistemaDeEntregasPIM.Controllers;

namespace SistemaDeEntregasPIM {
    public partial class Form1 : Form {

        string SqlConnection;

        public Form1() {
            InitializeComponent();
            SqlConnection = BancoDados.PegarLinhaDeConexao();
        }

        private void button1_Click(object sender, EventArgs e) {

            // Botão para logar dentro do sistema.

            if (comboTipoUsuario.Text == "cliente") {
                ControllerCliente controllerCliente = new ControllerCliente();
                controllerCliente.autenticarUsuario(login.Text, senha.Text);
            } else if (comboTipoUsuario.Text == "entregador") {
                ControllerEntregador controllerEntregador = new ControllerEntregador();
                controllerEntregador.autenticarUsuario(login.Text, senha.Text);
            } else if (comboTipoUsuario.Text == "fornecedor/restaurante") {
                ControllerFornecedor controllerFornecedor = new ControllerFornecedor();
                controllerFornecedor.autenticarUsuario(login.Text, senha.Text);
            } else {
                MessageBox.Show("ESCOLHA UM TIPO DE USUÁRIO!");
            }

        }

        private void label5_Click(object sender, EventArgs e) {
            this.Visible = false;
            FormularioDeCadastro formCadastro = new FormularioDeCadastro();
            formCadastro.Show();
        }
    }
}
