﻿using SistemaDeEntregasPIM.Models;
using SistemaDeEntregasPIM.Controllers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SistemaDeEntregasPIM {
    public partial class FormularioDeCadastro : Form {
        public FormularioDeCadastro() {
            InitializeComponent();

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e) {
            if (comboTipoUsuario.Text == "cliente" || comboTipoUsuario.Text == "entregador") {
                
                labelDataDeNascimento.Show();
                txtDataDeNascimento.Show();

                labelSexo.Show();
                comboSexo.Show();
                
                labelCnpj.Hide();
                txtCnpj.Hide();
            
            } else {
                
                labelDataDeNascimento.Hide();
                txtDataDeNascimento.Hide();

                labelSexo.Hide();
                comboSexo.Hide();

                labelCnpj.Show();
                txtCnpj.Show();

            }
        }

        private void button1_Click(object sender, EventArgs e) {
            if (comboTipoUsuario.Text == "cliente") {
                ModelCliente cliente = new ModelCliente();
                cliente.Login = txtLogin.Text;
                cliente.Senha = txtSenha.Text;
                cliente.Nome = txtNome.Text;
                cliente.DataDeNascimento = txtDataDeNascimento.Text;
                cliente.Sexo = comboSexo.Text;
                cliente.Endereco = txtEndereco.Text;
                cliente.Cep = txtCep.Text;
                cliente.Email = txtEmail.Text;
                cliente.Telefone = txtTelefone.Text;

                ControllerCadastro.registrarCliente(cliente);
            } else if (comboTipoUsuario.Text == "entregador") {
                ModelEntregador entregador = new ModelEntregador();
                entregador.Login = txtLogin.Text;
                entregador.Senha = txtSenha.Text;
                entregador.Nome = txtNome.Text;
                entregador.DataDeNascimento = txtDataDeNascimento.Text;
                entregador.Sexo = comboSexo.Text;
                entregador.Endereco = txtEndereco.Text;
                entregador.Cep = txtCep.Text;
                entregador.Email = txtEmail.Text;
                entregador.Telefone = txtTelefone.Text;

                ControllerCadastro.registrarEntregador(entregador);
            } else {
                ModelFornecedor fornecedor = new ModelFornecedor();
                fornecedor.Login = txtLogin.Text;
                fornecedor.Senha = txtSenha.Text;
                fornecedor.Nome = txtNome.Text;
                fornecedor.Cpnj = txtCnpj.Text;
                fornecedor.Endereco = txtEndereco.Text;
                fornecedor.Cep = txtCep.Text;
                fornecedor.Email = txtEmail.Text;
                fornecedor.Telefone = txtTelefone.Text;

                ControllerCadastro.registrarFornecedor(fornecedor);
            }
        }
    }
}
