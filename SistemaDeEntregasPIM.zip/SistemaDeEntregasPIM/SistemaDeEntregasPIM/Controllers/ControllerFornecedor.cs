﻿using SistemaDeEntregasPIM.Conexao;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace SistemaDeEntregasPIM.Controllers {
    class ControllerFornecedor : ControllerUsuario {

        public string Cnpj { get; set; }

        public bool autenticarUsuario(string login, string senha) {

            SqlConnection conexao = new SqlConnection(BancoDados.PegarLinhaDeConexao());
            
            SqlCommand comandoDeSelecao = new SqlCommand("SELECT * FROM Fornecedores WHERE login_fornecedor = '" + login + "' AND senha_fornecedor = CAST(N'" + senha + "' as varbinary(max))", conexao);

            conexao.Open();
            SqlDataReader leitor = comandoDeSelecao.ExecuteReader();
            Console.WriteLine(leitor.HasRows);
            try {
                // Procurar dentro banco de dados o usuário
                Console.WriteLine("HEY");
                while (leitor.Read()) {
                    Console.WriteLine("LEITURA");
                    if (leitor["login_fornecedor"].ToString() == login) {

                        string id = leitor["id_fornecedor"].ToString();
                        int idCliente = Convert.ToInt32(leitor["id_fornecedor"]);
                        Console.WriteLine(idCliente);
                        break;
                        return true;
                    }

                }
            }
            catch (Exception e) {
                MessageBox.Show(e.Message);
                return false;
            }
            finally {
                // Finalizar leitor e conexão
                if (leitor != null) {
                    leitor.Close();
                }

                if (conexao != null) {
                    conexao.Close();
                }
            }

            return true;
        }
    }
}
