﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using SistemaDeEntregasPIM.Conexao;

namespace SistemaDeEntregasPIM.Controllers {
    public class ControllerUsuario {
        public string Login { get; set; }
        public string Senha { get; set; }
        public string Nome { get; set; }
        public string Endereco { get; set; }
        public string Cep { get; set; }
        public string Email { get; set; }
        public string Telefone { get; set; }

        public bool autenticarUsuario() {

            // Será utilizado o conceito de polimorfismo para modificar essa função
            // Por isso apenas conterá esse retorno simples
            return true;
        }
        
    }
}
