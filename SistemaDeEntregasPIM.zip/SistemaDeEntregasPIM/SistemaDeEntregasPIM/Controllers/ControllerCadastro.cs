﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SistemaDeEntregasPIM.Conexao;
using SistemaDeEntregasPIM.Models;
using System.Data.SqlClient;

namespace SistemaDeEntregasPIM.Controllers {
    public class ControllerCadastro {

        // Este controller irá realizar o cadastro de todos os tipos de usuários.

        public static bool registrarCliente(ModelCliente cliente) {
            try {
                
                string linhaDoComando = "INSERT INTO Usuarios (login_usuario, senha_usuario, nome_usuario, data_nascimento, sexo, endereco_usuario, cep_usuario,email_usuario,telefone_usuario)" +
                    "VALUES (@login, CAST(@senha as varbinary(max)), @nome, @dataNascimento, @sexo, @endereco, @cep, @email, @telefone);";

                SqlConnection conexao = new SqlConnection(BancoDados.PegarLinhaDeConexao());
                SqlCommand comandoDeInsercao = new SqlCommand(linhaDoComando, conexao);

                comandoDeInsercao.Parameters.Add(new SqlParameter("@login", cliente.Login));
                comandoDeInsercao.Parameters.Add(new SqlParameter("@senha", cliente.Senha));
                comandoDeInsercao.Parameters.Add(new SqlParameter("@nome", cliente.Nome));
                comandoDeInsercao.Parameters.Add(new SqlParameter("@dataNascimento", cliente.DataDeNascimento));
                comandoDeInsercao.Parameters.Add(new SqlParameter("@sexo", cliente.Sexo));
                comandoDeInsercao.Parameters.Add(new SqlParameter("@endereco", cliente.Endereco));
                comandoDeInsercao.Parameters.Add(new SqlParameter("@cep", cliente.Cep));
                comandoDeInsercao.Parameters.Add(new SqlParameter("@email", cliente.Email));
                comandoDeInsercao.Parameters.Add(new SqlParameter("@telefone", cliente.Telefone));

                conexao.Open();

                comandoDeInsercao.ExecuteNonQuery();

                conexao.Close();

                MessageBox.Show("Cadastro feito com sucesso!");

            } catch (Exception e) {
                MessageBox.Show(e.Message);
            }
            return true;
        }

        public static bool registrarEntregador(ModelEntregador entregador) {
            try {

                string linhaDoComando = "INSERT INTO Entregadores (login_entregador, senha_entregador, nome_entregador, data_nascimento, sexo, endereco_entregador, cep_entregador,email_entregador,telefone_entregador)" +
                    "VALUES (@login, CAST(@senha as varbinary(max)), @nome, @dataNascimento, @sexo, @endereco, @cep, @email, @telefone);";

                SqlConnection conexao = new SqlConnection(BancoDados.PegarLinhaDeConexao());
                SqlCommand comandoDeInsercao = new SqlCommand(linhaDoComando, conexao);

                comandoDeInsercao.Parameters.Add(new SqlParameter("@login", entregador.Login));
                comandoDeInsercao.Parameters.Add(new SqlParameter("@senha", entregador.Senha));
                comandoDeInsercao.Parameters.Add(new SqlParameter("@nome", entregador.Nome));
                comandoDeInsercao.Parameters.Add(new SqlParameter("@dataNascimento", entregador.DataDeNascimento));
                comandoDeInsercao.Parameters.Add(new SqlParameter("@sexo", entregador.Sexo));
                comandoDeInsercao.Parameters.Add(new SqlParameter("@endereco", entregador.Endereco));
                comandoDeInsercao.Parameters.Add(new SqlParameter("@cep", entregador.Cep));
                comandoDeInsercao.Parameters.Add(new SqlParameter("@email", entregador.Email));
                comandoDeInsercao.Parameters.Add(new SqlParameter("@telefone", entregador.Telefone));

                conexao.Open();

                comandoDeInsercao.ExecuteNonQuery();

                conexao.Close();

                MessageBox.Show("Cadastro feito com sucesso!");

            }
            catch (Exception e) {
                MessageBox.Show(e.Message);
            }
            return true;
        }

        public static bool registrarFornecedor(ModelFornecedor fornecedor) {
            try {

                string linhaDoComando = "INSERT INTO Fornecedores (login_fornecedor, senha_fornecedor, nome_fornecedor, cnpj_fornecedor, endereco_fornecedor, cep_fornecedor,email_fornecedor,telefone_fornecedor)" +
                    "VALUES (@login, CAST(@senha as varbinary(max)), @nome, @cnpj, @endereco, @cep, @email, @telefone);";

                SqlConnection conexao = new SqlConnection(BancoDados.PegarLinhaDeConexao());
                SqlCommand comandoDeInsercao = new SqlCommand(linhaDoComando, conexao);

                comandoDeInsercao.Parameters.Add(new SqlParameter("@login", fornecedor.Login));
                comandoDeInsercao.Parameters.Add(new SqlParameter("@senha", fornecedor.Senha));
                comandoDeInsercao.Parameters.Add(new SqlParameter("@nome", fornecedor.Nome));
                comandoDeInsercao.Parameters.Add(new SqlParameter("@cnpj", fornecedor.Cpnj));
                comandoDeInsercao.Parameters.Add(new SqlParameter("@endereco", fornecedor.Endereco));
                comandoDeInsercao.Parameters.Add(new SqlParameter("@cep", fornecedor.Cep));
                comandoDeInsercao.Parameters.Add(new SqlParameter("@email", fornecedor.Email));
                comandoDeInsercao.Parameters.Add(new SqlParameter("@telefone", fornecedor.Telefone));

                conexao.Open();

                comandoDeInsercao.ExecuteNonQuery();

                conexao.Close();

                MessageBox.Show("Cadastro feito com sucesso!");

            }
            catch (Exception e) {
                MessageBox.Show(e.Message);
            }
            return true;
        }

    }
}
