﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SistemaDeEntregasPIM.Models;

namespace SistemaDeEntregasPIM.Controllers {
    public class ControllerCadastro {

        public static bool registrarCliente(ModelCliente cliente) {
            MessageBox.Show("Registrar cliente");
            return true;
        }

        public static bool registrarEntregador(ModelEntregador entregador) {
            MessageBox.Show("Registrar entregador");
            return true;
        }

        public static bool registrarFornecedor(ModelFornecedor fornecedor) {
            MessageBox.Show("Registrar fornecedor");
            return true;
        }

    }
}
